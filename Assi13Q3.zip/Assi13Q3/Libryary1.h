void CheckPerfect(int num);
