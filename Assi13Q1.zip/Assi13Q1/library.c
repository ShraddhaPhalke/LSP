
void Search(int *brr,int no)
{
	int i = 0;
	int chk = 0;
	for(i=0;i<=10;i++)
	{
		if(no == brr[i])
		{
			chk = 1;
			break;
		}		
	
	}
	if(chk == 0)
	{
		printf("Number is not present in array\n");
	}
	else
	{
		printf("Number is present in array\n");
	}		
}

void Sort(int * arr)
{

	int i,j,temp;
	for(i=0;i<=9;i++)
	{
		for(j=i+1;j<=9;j++)
		{
			if(arr[i] > arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}		


	}
	
}

