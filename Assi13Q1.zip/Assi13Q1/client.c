#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include "libryry.h"

int main()
{
	
	int arr[10]={1,2,3,4,5,6,7,8,9,10};
	int arr1[10]={2,4,6,7,5,8,1,5,3,6};
	int num = 0,i = 0;
	
	printf("enter number you want to search\n");
	scanf("%d",&num);
	
	
	Search(arr,num);
	
	printf("Unsorted Array :\n");
	for(i=0; i<=9; i++)
	{
		printf("%d ",arr1[i]);
	}	
	
	Sort(arr1);
	
	printf("\nSorted Array :\n");
	for(i=0; i<=9; i++)
	{
		printf("%d ",arr1[i]);
	}	
	
return 0;
}
