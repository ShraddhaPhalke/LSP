#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include "Library1.h"

int main()
{
	int num = 0, ret = 0;
	
	printf("Enter number to check perfect or not\n");
	scanf("%d",&num);
	
	ret = CheckPerfect(num);
	
	return 0;
}	
