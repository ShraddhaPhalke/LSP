#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include "Library1.h"
#include "Library2.h"

int main()
{
	int n=10,i=0;
	int arr[n];
	int ret1 = 0, ret2 = 0;
	
	
	printf("Enter array elements\n");
	for(i=0; i<n; i++)
	{
		scanf("%d",&arr[i]);
	}
	
	ret1 = Max(arr,n);
	printf("Max number : %d\n",ret1);
	
	ret2 = Min(arr,n);
	printf("Min number : %d\n",ret2);	


return 0;
}

/* 
To compile :
gcc Client.c -o myexe Library1.a Library2.a

*/
