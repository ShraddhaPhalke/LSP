
int SumFactors(int num);
			 
