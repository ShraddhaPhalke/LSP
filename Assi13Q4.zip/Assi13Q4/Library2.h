int Min(int * arr, int n);
			

