int Min(int * arr, int n)
{
	int min = arr[0];
	int i = 0;
	
	for(i=0; i<n; i++)
	{
		if(arr[i] < min)
		{
			min = arr[i];
		}
	}
	
	return min;
}	
