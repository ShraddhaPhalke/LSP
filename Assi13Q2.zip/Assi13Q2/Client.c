#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include "Library.h"
int main()
{
	int num = 0,ret = 0;
	printf("Enter number \n");
	scanf("%d",&num);
	
	ret  = SumFactors(num);
	
	printf("sum of factors of %d is %d\n",num,ret);

return 0;
}
