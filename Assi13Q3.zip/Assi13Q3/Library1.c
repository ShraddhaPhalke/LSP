#include<stdio.h>

void CheckPerfect(int num)
{

	int ret = 0, chk = 0;
	
	ret = SumFactors(num);
	
	if(num  == ret)
	{
		printf("%d Number is perfect number\n",num);
	}
	else
	{
		printf("%d Number is not perfect number\n",num);
	}
}			

/*
to create Library1.o file:
gcc -c -fpic Library1.c

To create Library1.a file:

ar rcs Library1.a Library1.o Library.o

*/
